#!/bin/bash
set -e

CURRENT_USER="${SUDO_USER:-$(stat -f%Su /dev/console)}"
USER_UID="$(id -u "$CURRENT_USER")"
USER_HOME="$(dscl . -read "/Users/$CURRENT_USER" NFSHomeDirectory | awk '{print $2}')"

LAUNCH_AGENT="$USER_HOME/Library/LaunchAgents/com.davutsumer.audiorouter.helper.plist"
USER_APP_SUPPORT="$USER_HOME/Library/Application Support/AudioRouter"
DRIVER_PATH="/Library/Audio/Plug-Ins/HAL/AudioRouter.driver"
SYSTEM_APP_SUPPORT="/Library/Application Support/AudioRouter"

echo "Unloading LaunchAgent for user: $CURRENT_USER"
launchctl bootout "gui/$USER_UID" "$LAUNCH_AGENT" 2>/dev/null || true

echo "Removing LaunchAgent plist"
rm -f "$LAUNCH_AGENT"

echo "Removing user Application Support"
rm -rf "$USER_APP_SUPPORT"

echo "Removing HAL driver"
rm -rf "$DRIVER_PATH"

echo "Removing shared support directory"
rm -rf "$SYSTEM_APP_SUPPORT"

echo "Restarting coreaudiod"
killall -9 coreaudiod 2>/dev/null || true

exit 0
